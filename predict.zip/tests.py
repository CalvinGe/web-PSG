from django.test import TestCase
import network
import numpy as np
import json
import requests
from threading import Thread
from time import sleep, ctime

# Create your tests here.
# image = network.generate_image('tr03-0005')

image = np.load('../edf_data/tr03-0005.npy')

print(image.shape)
# ===========================
# ******多值写入示例***********
# ===========================

# requests.adapters.DEFAULT_RETRIES = 5
#
#
# def multi_post(image, start, end):
#     for i in range(start, end):
#         payload = [
#             {
#                 "metric": "ZhouSC",
#                 "fields": {
#                     "F3-M2": image[0, i],
#                     "F4-M1": image[1, i],
#                     "C3-M2": image[2, i],
#                     "C4-M1": image[3, i],
#                     "O1-M2": image[4, i],
#                     "O2-M1": image[5, i],
#                     "E1-M2": image[6, i],
#                     "Chin1-Chin2": image[7, i],
#                     "ABD": image[8, i],
#                     "CHEST": image[9, i],
#                     "AIRFLOW": image[10, i],
#                     "SaO2": image[11, i],
#                     "ECG": image[12, i],
#                 },
#                 "tags": {
#                     "hospital": "Children hospital",
#                     "province": "Shanghai",
#                     "country": "china"
#                 },
#                 "timestamp": 1346846401 + i
#             }
#         ]
#
#         response = requests.post('http://ts-bp1pu6g127q08m92q.hitsdb.rds.aliyuncs.com:3242/api/mput?summary',
#                                  data=json.dumps(payload), headers={'Content-Type': 'application/json'})
#         if start == 0:
#             print('Finish posting ', i)
#         sleep(0.001)
#
#     print(response.text)
#
#
# # t1 = Thread(target=multi_post, args=(image, 0, 10000))
# # t2 = Thread(target=multi_post, args=(image, 10000, 20000))
# #
# # t1.start()
# # t2.start()
# #
# # t1.join()
# # t2.join()
#
# t = []
# thread_len = 10000
# num_thread = int(image.shape[1] / thread_len)
# for i in range(num_thread):
#     start = i * thread_len
#     end = (i + 1) * thread_len
#     if num_thread - i == 1:
#         end = image.shape[1]
#     cur_t = Thread(target=multi_post, args=(image, start, end))
#     t.append(cur_t)
#
# for each_thread in t:
#     each_thread.start()
#
# for each_thread in t:
#     each_thread.join()

# 神经网络进行预测

model_path = './data/weights/'
spec_path = './data/specs/'
path1 = './data/avg8_8m_multi_task_image/'
channel_idx = [0, 1, 2, 3, 4, 5, 6, 7]
label_idx = [0, 1, 2, 3, 4, 5, 6, 7]
all_id = ['tr03-0005']

network.predict(model_path, spec_path, channel_idx, label_idx, path1, all_id)
