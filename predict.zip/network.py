import numpy as np
import scipy.io
import cv2

import os, sys
import pandas as pd
from glob import glob
import unet as unet
import pickle
from keras.utils.np_utils import to_categorical
from keras import backend as K
import tensorflow as tf
import keras
import argparse
from sklearn.metrics import classification_report, confusion_matrix, precision_score, recall_score, f1_score
import sklearn.metrics as metrics


def import_signals(file_name):  # feature
    return scipy.io.loadmat(file_name)['val']


def anchor(ref, ori):  # input m*n np array
    d0 = ori.shape[0]
    d1 = ori.shape[1]
    ref = cv2.resize(ref, (d1, d0), interpolation=cv2.INTER_AREA)
    ori_new = ori.copy()
    for i in range(d0):
        ori_new[i, np.argsort(ori[i, :])] = ref[i, :]
    return ori_new


def label_major_vote(input_data, scale_pool):
    size_new = int(input_data.shape[1] / scale_pool)
    input_data = input_data.reshape(size_new, scale_pool).T
    input_data = input_data.astype(int) + 1  # bincount need non-negative, int dtype
    counts = np.apply_along_axis(lambda x: np.bincount(x, minlength=3), axis=0, arr=input_data)
    major = np.apply_along_axis(lambda x: np.argmax(x), axis=0, arr=counts) - 1
    major = major.reshape(1, len(major))
    return major


ref555 = np.load('./data/ref555_13c.npy')

path1 = './data/image_data/'
path2 = './data/avg8_8m_multi_task_image/'
size = 4096 * 256
num_pool = 3
scale_pool = 2 ** num_pool
num = 0


def generate_image(filename):
    pid = filename.rstrip()
    pid = pid.split('/')[-1]
    print(pid)
    # arousal_file = path1 + each_id + '/' + each_id + '-arousal.mat'
    # label = import_arousals(arousal_file)
    signal_file = path1 + pid + '.mat'
    image_ori = import_signals(signal_file)
    image = anchor(ref555, image_ori)
    d0 = image.shape[0]
    d1 = image.shape[1]
    if d1 < size * scale_pool:
        image = np.concatenate((image, np.zeros((d0, size * scale_pool - d1))), axis=1)
        # label=np.concatenate((label,np.zeros((1,size*scale_pool-d1))-1),axis=1)
    image = cv2.resize(image, (size, d0), interpolation=cv2.INTER_AREA)  # average pool
    print('image: ', image.shape)
    # label=label_major_vote(label,scale_pool)
    np.save(path2 + pid, image)
    # np.save(path3 + each_id , label)
    return image


def predict(model_path, spec_path, channel_idx, label_idx, path1, all_id):
    # initisate keras
    config = tf.compat.v1.ConfigProto()
    config.gpu_options.per_process_gpu_memory_fraction = 0.5
    tf.compat.v1.keras.backend.set_session(tf.compat.v1.Session(config=config))
    K.set_image_data_format('channels_last')

    # hyperparameter
    size = 4096 * 256
    channel = len(channel_idx)
    print(channel)
    labels = ['Undefined', 'Wake', 'N1', 'N2', 'N3', 'REM', 'Arousal', 'Apnea']
    labels = [labels[i] for i in label_idx]
    print(labels)
    batch = 1
    num_class = len(labels)  # arousal

    allpath = glob(model_path + '*.h5')
    print(allpath)
    model = {i: unet.get_unet(size, channel, num_class) for i in range(len(allpath))}
    for i in range(len(allpath)):
        model[i].load_weights(allpath[i])

    # evaluation
    all_test_eva = open('./eva_test.txt', 'w')
    all_test_eva.write(
        'id\tlabel\tAUROC\tAUPRC\tSensitivity\tSpecificity\tPrecision\tAccuracy\tF1\tauprc_baseline\ttotal_length\n')

    pred_all = []
    gs_all = []
    # sleep_conf_mat = np.zeros((5,5))
    arousal_conf_mat = np.zeros((2, 2))
    apnea_conf_mat = np.zeros((2, 2))
    # load files

    for the_id in all_id:

        # select 3  signal channels
        signal = np.load(path1 + the_id + '.npy')[channel_idx, :]
        # label = np.load(path2 + the_id + '.npy')[label_idx, :]
        # print('label shape:', label.shape)
        # d2 = label.shape[1]

        input_pred = np.reshape(signal.T, (batch, size, channel))
        output1 = []
        output2 = []
        output3 = []
        # use model to predict, 5 predicts/model then use average as output
        for m in model.values():  # [model0, model1, model2, model3, model4]:
            output_ori = m.predict(input_pred)
            output1.append(output_ori[0])
            output2.append(output_ori[1])
            output3.append(output_ori[2])
        output1 = np.mean(np.vstack(output1), axis=0).T
        output2 = np.mean(np.vstack(output2), axis=0).T
        output3 = np.mean(np.vstack(output3), axis=0).T

        print(output1.shape, output2.shape, output3.shape)
        np.save(spec_path + the_id + '_sleep', output1)
        np.save(spec_path + the_id + '_arousal', output2)
        np.save(spec_path + the_id + '_apnea', output3)

        output1_cat = np.round(output1 / output1.max(axis=0))
