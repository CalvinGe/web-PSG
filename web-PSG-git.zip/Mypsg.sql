/*
 Navicat Premium Data Transfer

 Source Server         : calvin
 Source Server Type    : MySQL
 Source Server Version : 80026
 Source Host           : localhost:3306
 Source Schema         : mypsg

 Target Server Type    : MySQL
 Target Server Version : 80026
 File Encoding         : 65001

 Date: 15/01/2022 21:39:25
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for auth_group
-- ----------------------------
DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name`(`name`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_group
-- ----------------------------

-- ----------------------------
-- Table structure for auth_group_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_group_permissions_group_id_permission_id_0cd325b0_uniq`(`group_id`, `permission_id`) USING BTREE,
  INDEX `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm`(`permission_id`) USING BTREE,
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_group_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for auth_permission
-- ----------------------------
DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_permission_content_type_id_codename_01ab375a_uniq`(`content_type_id`, `codename`) USING BTREE,
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 49 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_permission
-- ----------------------------
INSERT INTO `auth_permission` VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO `auth_permission` VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO `auth_permission` VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO `auth_permission` VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO `auth_permission` VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO `auth_permission` VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO `auth_permission` VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO `auth_permission` VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO `auth_permission` VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO `auth_permission` VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO `auth_permission` VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO `auth_permission` VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO `auth_permission` VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO `auth_permission` VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO `auth_permission` VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO `auth_permission` VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO `auth_permission` VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO `auth_permission` VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO `auth_permission` VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO `auth_permission` VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO `auth_permission` VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO `auth_permission` VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO `auth_permission` VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO `auth_permission` VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO `auth_permission` VALUES (25, 'Can add event', 7, 'add_event');
INSERT INTO `auth_permission` VALUES (26, 'Can change event', 7, 'change_event');
INSERT INTO `auth_permission` VALUES (27, 'Can delete event', 7, 'delete_event');
INSERT INTO `auth_permission` VALUES (28, 'Can view event', 7, 'view_event');
INSERT INTO `auth_permission` VALUES (29, 'Can add breath event', 8, 'add_breathevent');
INSERT INTO `auth_permission` VALUES (30, 'Can change breath event', 8, 'change_breathevent');
INSERT INTO `auth_permission` VALUES (31, 'Can delete breath event', 8, 'delete_breathevent');
INSERT INTO `auth_permission` VALUES (32, 'Can view breath event', 8, 'view_breathevent');
INSERT INTO `auth_permission` VALUES (33, 'Can add diagnosis', 9, 'add_diagnosis');
INSERT INTO `auth_permission` VALUES (34, 'Can change diagnosis', 9, 'change_diagnosis');
INSERT INTO `auth_permission` VALUES (35, 'Can delete diagnosis', 9, 'delete_diagnosis');
INSERT INTO `auth_permission` VALUES (36, 'Can view diagnosis', 9, 'view_diagnosis');
INSERT INTO `auth_permission` VALUES (37, 'Can add patient', 10, 'add_patient');
INSERT INTO `auth_permission` VALUES (38, 'Can change patient', 10, 'change_patient');
INSERT INTO `auth_permission` VALUES (39, 'Can delete patient', 10, 'delete_patient');
INSERT INTO `auth_permission` VALUES (40, 'Can view patient', 10, 'view_patient');
INSERT INTO `auth_permission` VALUES (41, 'Can add record', 11, 'add_record');
INSERT INTO `auth_permission` VALUES (42, 'Can change record', 11, 'change_record');
INSERT INTO `auth_permission` VALUES (43, 'Can delete record', 11, 'delete_record');
INSERT INTO `auth_permission` VALUES (44, 'Can view record', 11, 'view_record');
INSERT INTO `auth_permission` VALUES (45, 'Can add sleep event', 12, 'add_sleepevent');
INSERT INTO `auth_permission` VALUES (46, 'Can change sleep event', 12, 'change_sleepevent');
INSERT INTO `auth_permission` VALUES (47, 'Can delete sleep event', 12, 'delete_sleepevent');
INSERT INTO `auth_permission` VALUES (48, 'Can view sleep event', 12, 'view_sleepevent');

-- ----------------------------
-- Table structure for auth_user
-- ----------------------------
DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE `auth_user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `last_login` datetime(6) NULL DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `first_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `last_name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user
-- ----------------------------
INSERT INTO `auth_user` VALUES (1, 'pbkdf2_sha256$260000$Y4xl6I79Kt8TaOuhSUbYVG$H8hoI4OWMNAuoMq0HppLJ8ccfV5qE5XrEeqO2Qq7pfA=', '2022-01-15 12:46:29.176280', 1, 'calvin', '', '', 'calvins@sjtu.edu.cn', 1, 1, '2022-01-13 01:17:25.939417');
INSERT INTO `auth_user` VALUES (2, 'pbkdf2_sha256$260000$1ZjMrqANio2O2W3LkOgqVr$K0NJn8YMmhIH1owa/DFYtwQzZukFbsyX4OJmBHPOrns=', '2022-01-15 08:22:40.604731', 1, 'song', '', '', 'calvins@sjtu.edu.cn', 1, 1, '2022-01-15 07:00:22.052384');

-- ----------------------------
-- Table structure for auth_user_groups
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE `auth_user_groups`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_groups_user_id_group_id_94350c0c_uniq`(`user_id`, `group_id`) USING BTREE,
  INDEX `auth_user_groups_group_id_97559544_fk_auth_group_id`(`group_id`) USING BTREE,
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user_groups
-- ----------------------------

-- ----------------------------
-- Table structure for auth_user_user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE `auth_user_user_permissions`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq`(`user_id`, `permission_id`) USING BTREE,
  INDEX `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm`(`permission_id`) USING BTREE,
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of auth_user_user_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for common_breathevent
-- ----------------------------
DROP TABLE IF EXISTS `common_breathevent`;
CREATE TABLE `common_breathevent`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `end` datetime(6) NOT NULL,
  `start` datetime(6) NOT NULL,
  `record_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `common_breathevent_record_id_c1585ec8_fk_common_record_id`(`record_id`) USING BTREE,
  CONSTRAINT `common_breathevent_record_id_c1585ec8_fk_common_record_id` FOREIGN KEY (`record_id`) REFERENCES `common_record` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 52 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of common_breathevent
-- ----------------------------
INSERT INTO `common_breathevent` VALUES (2, 'Apnea', '2022-01-01 19:00:05.000000', '2022-01-01 19:00:00.000000', 3);
INSERT INTO `common_breathevent` VALUES (3, 'Apnea', '2021-12-04 10:00:11.000000', '2021-12-04 10:00:00.000000', 10);
INSERT INTO `common_breathevent` VALUES (4, 'Apnea', '2021-12-04 13:00:12.000000', '2021-12-04 13:00:00.000000', 11);
INSERT INTO `common_breathevent` VALUES (5, 'Apnea', '2021-12-08 03:47:46.000000', '2021-12-08 03:47:35.000000', 12);
INSERT INTO `common_breathevent` VALUES (6, 'Apnea', '2021-12-07 23:55:14.000000', '2021-12-07 23:55:04.000000', 13);
INSERT INTO `common_breathevent` VALUES (7, 'Apnea', '2021-12-09 23:43:12.000000', '2021-12-09 23:43:00.000000', 14);
INSERT INTO `common_breathevent` VALUES (8, 'Apnea', '2021-12-07 23:48:13.000000', '2021-12-07 23:48:03.000000', 15);
INSERT INTO `common_breathevent` VALUES (9, 'Hypopnea', '2021-12-12 03:20:33.000000', '2021-12-12 03:20:22.000000', 16);
INSERT INTO `common_breathevent` VALUES (10, 'Hypopnea', '2021-12-13 04:36:20.000000', '2021-12-13 04:30:20.000000', 16);
INSERT INTO `common_breathevent` VALUES (11, 'Hypopnea', '2021-12-13 21:10:00.000000', '2021-12-13 21:00:00.000000', 18);
INSERT INTO `common_breathevent` VALUES (12, 'Hypopnea', '2021-12-14 22:08:00.000000', '2021-12-14 22:00:00.000000', 18);
INSERT INTO `common_breathevent` VALUES (13, 'Hypopnea', '2021-12-15 01:10:00.000000', '2021-12-15 01:10:00.000000', 20);
INSERT INTO `common_breathevent` VALUES (14, 'Hypopnea', '2021-12-15 23:12:00.000000', '2021-12-15 23:00:00.000000', 21);
INSERT INTO `common_breathevent` VALUES (15, 'Hypopnea', '2021-12-17 17:40:00.000000', '2021-12-17 17:00:00.000000', 22);
INSERT INTO `common_breathevent` VALUES (16, 'Hypopnea', '2021-12-19 00:19:00.000000', '2021-12-19 00:10:00.000000', 23);
INSERT INTO `common_breathevent` VALUES (17, 'Hypopnea', '2021-12-19 00:56:00.000000', '2021-12-19 00:48:00.000000', 23);
INSERT INTO `common_breathevent` VALUES (18, 'Apnea', '2021-12-17 17:30:14.000000', '2021-12-17 17:30:00.000000', 22);
INSERT INTO `common_breathevent` VALUES (19, 'Apnea', '2021-12-17 20:00:22.000000', '2021-12-17 20:00:00.000000', 22);
INSERT INTO `common_breathevent` VALUES (20, 'Hypopnea', '2021-12-04 00:08:20.000000', '2021-12-04 00:08:08.000000', 8);
INSERT INTO `common_breathevent` VALUES (21, 'Hypopnea', '2021-12-05 01:16:13.000000', '2021-12-05 01:16:00.000000', 9);
INSERT INTO `common_breathevent` VALUES (22, 'Hypopnea', '2022-01-04 02:34:14.000000', '2022-01-04 02:34:00.000000', 31);
INSERT INTO `common_breathevent` VALUES (23, 'Apnea', '2021-12-23 01:20:23.000000', '2021-12-23 01:20:00.000000', 30);
INSERT INTO `common_breathevent` VALUES (24, 'Apnea', '2021-12-23 02:20:11.000000', '2021-12-23 02:20:00.000000', 30);
INSERT INTO `common_breathevent` VALUES (25, 'Apnea', '2021-12-18 23:57:14.000000', '2021-12-18 23:57:00.000000', 23);
INSERT INTO `common_breathevent` VALUES (26, 'Apnea', '2021-12-19 23:36:24.000000', '2021-12-19 23:36:00.000000', 24);
INSERT INTO `common_breathevent` VALUES (27, 'Apnea', '2021-12-20 23:04:22.000000', '2021-12-20 23:04:01.000000', 25);
INSERT INTO `common_breathevent` VALUES (28, 'Apnea', '2021-12-22 02:40:20.000000', '2021-12-22 02:40:00.000000', 26);
INSERT INTO `common_breathevent` VALUES (51, 'Apnea', '2021-12-22 02:40:10.000000', '2021-12-22 02:40:05.000000', 23);

-- ----------------------------
-- Table structure for common_diagnosis
-- ----------------------------
DROP TABLE IF EXISTS `common_diagnosis`;
CREATE TABLE `common_diagnosis`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid_id` int NOT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `common_diagnosis_pid_id_5f09812f_fk_common_patient_id`(`pid_id`) USING BTREE,
  INDEX `common_diagnosis_user_id_1d45b9ae_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `common_diagnosis_pid_id_5f09812f_fk_common_patient_id` FOREIGN KEY (`pid_id`) REFERENCES `common_patient` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `common_diagnosis_user_id_1d45b9ae_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of common_diagnosis
-- ----------------------------
INSERT INTO `common_diagnosis` VALUES (1, 3, 1);
INSERT INTO `common_diagnosis` VALUES (3, 8, 1);
INSERT INTO `common_diagnosis` VALUES (4, 36, 1);
INSERT INTO `common_diagnosis` VALUES (5, 9, 1);
INSERT INTO `common_diagnosis` VALUES (6, 13, 1);
INSERT INTO `common_diagnosis` VALUES (7, 18, 1);
INSERT INTO `common_diagnosis` VALUES (8, 21, 1);
INSERT INTO `common_diagnosis` VALUES (9, 25, 1);
INSERT INTO `common_diagnosis` VALUES (10, 28, 1);
INSERT INTO `common_diagnosis` VALUES (11, 5, 2);
INSERT INTO `common_diagnosis` VALUES (12, 12, 2);
INSERT INTO `common_diagnosis` VALUES (13, 13, 2);
INSERT INTO `common_diagnosis` VALUES (14, 14, 2);
INSERT INTO `common_diagnosis` VALUES (15, 15, 2);
INSERT INTO `common_diagnosis` VALUES (16, 16, 2);
INSERT INTO `common_diagnosis` VALUES (17, 17, 2);
INSERT INTO `common_diagnosis` VALUES (18, 18, 2);
INSERT INTO `common_diagnosis` VALUES (19, 19, 2);
INSERT INTO `common_diagnosis` VALUES (20, 20, 2);
INSERT INTO `common_diagnosis` VALUES (21, 21, 2);
INSERT INTO `common_diagnosis` VALUES (22, 22, 2);
INSERT INTO `common_diagnosis` VALUES (23, 23, 2);
INSERT INTO `common_diagnosis` VALUES (24, 24, 2);
INSERT INTO `common_diagnosis` VALUES (25, 25, 2);

-- ----------------------------
-- Table structure for common_event
-- ----------------------------
DROP TABLE IF EXISTS `common_event`;
CREATE TABLE `common_event`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_id` int NOT NULL,
  `start` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `common_event_record_id_44ba122d_fk_common_record_id`(`record_id`) USING BTREE,
  CONSTRAINT `common_event_record_id_44ba122d_fk_common_record_id` FOREIGN KEY (`record_id`) REFERENCES `common_record` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of common_event
-- ----------------------------
INSERT INTO `common_event` VALUES (2, 3, '2022-01-01 19:00:00.000000');
INSERT INTO `common_event` VALUES (3, 10, '2021-12-04 10:00:00.000000');
INSERT INTO `common_event` VALUES (4, 11, '2021-12-04 13:00:00.000000');
INSERT INTO `common_event` VALUES (5, 12, '2021-12-08 03:47:35.000000');
INSERT INTO `common_event` VALUES (6, 13, '2021-12-07 23:55:04.000000');
INSERT INTO `common_event` VALUES (7, 14, '2021-12-09 23:43:00.000000');
INSERT INTO `common_event` VALUES (8, 15, '2021-12-07 23:48:03.000000');
INSERT INTO `common_event` VALUES (9, 16, '2021-12-12 03:20:22.000000');
INSERT INTO `common_event` VALUES (10, 16, '2021-12-13 04:30:20.000000');
INSERT INTO `common_event` VALUES (11, 18, '2021-12-13 21:00:00.000000');
INSERT INTO `common_event` VALUES (12, 18, '2021-12-14 22:00:00.000000');
INSERT INTO `common_event` VALUES (13, 20, '2021-12-15 01:10:00.000000');
INSERT INTO `common_event` VALUES (14, 21, '2021-12-15 23:00:00.000000');
INSERT INTO `common_event` VALUES (15, 22, '2021-12-17 17:00:00.000000');
INSERT INTO `common_event` VALUES (16, 23, '2021-12-19 00:10:00.000000');
INSERT INTO `common_event` VALUES (17, 23, '2021-12-19 00:48:00.000000');
INSERT INTO `common_event` VALUES (18, 22, '2021-12-17 17:30:00.000000');
INSERT INTO `common_event` VALUES (19, 22, '2021-12-17 20:00:00.000000');
INSERT INTO `common_event` VALUES (20, 8, '2021-12-04 00:08:08.000000');
INSERT INTO `common_event` VALUES (21, 9, '2021-12-05 01:16:00.000000');
INSERT INTO `common_event` VALUES (22, 31, '2022-01-04 02:34:00.000000');
INSERT INTO `common_event` VALUES (23, 30, '2021-12-23 01:20:00.000000');
INSERT INTO `common_event` VALUES (24, 30, '2021-12-23 02:20:00.000000');
INSERT INTO `common_event` VALUES (25, 23, '2021-12-18 23:57:00.000000');
INSERT INTO `common_event` VALUES (26, 24, '2021-12-19 23:36:00.000000');
INSERT INTO `common_event` VALUES (27, 25, '2021-12-20 23:04:01.000000');
INSERT INTO `common_event` VALUES (28, 26, '2021-12-22 02:40:00.000000');
INSERT INTO `common_event` VALUES (29, 8, '2021-12-03 23:00:00.000000');
INSERT INTO `common_event` VALUES (30, 8, '2021-12-04 00:00:00.000000');
INSERT INTO `common_event` VALUES (31, 8, '2021-12-04 00:40:00.000000');
INSERT INTO `common_event` VALUES (32, 10, '2021-12-04 23:54:00.000000');
INSERT INTO `common_event` VALUES (33, 10, '2021-12-04 23:22:00.000000');
INSERT INTO `common_event` VALUES (34, 11, '2021-12-04 09:00:00.000000');
INSERT INTO `common_event` VALUES (35, 11, '2021-12-04 09:38:00.000000');
INSERT INTO `common_event` VALUES (36, 11, '2021-12-04 10:22:00.000000');
INSERT INTO `common_event` VALUES (37, 14, '2021-12-10 00:00:00.000000');
INSERT INTO `common_event` VALUES (38, 15, '2021-12-10 16:54:00.000000');
INSERT INTO `common_event` VALUES (39, 16, '2021-12-12 01:00:00.000000');
INSERT INTO `common_event` VALUES (40, 16, '2021-12-12 02:00:00.000000');
INSERT INTO `common_event` VALUES (41, 17, '2021-12-12 23:30:00.000000');
INSERT INTO `common_event` VALUES (42, 18, '2021-12-13 17:00:00.000000');
INSERT INTO `common_event` VALUES (43, 19, '2021-12-13 21:00:00.000000');
INSERT INTO `common_event` VALUES (44, 20, '2021-12-14 22:48:00.000000');
INSERT INTO `common_event` VALUES (45, 21, '2021-12-15 23:50:00.000000');
INSERT INTO `common_event` VALUES (46, 22, '2021-12-17 16:30:00.000000');
INSERT INTO `common_event` VALUES (47, 22, '2021-12-17 17:30:00.000000');
INSERT INTO `common_event` VALUES (48, 25, '2021-12-21 01:20:00.000000');
INSERT INTO `common_event` VALUES (49, 26, '2021-12-22 00:40:00.000000');
INSERT INTO `common_event` VALUES (50, 3, '2022-01-04 09:00:05.000000');
INSERT INTO `common_event` VALUES (51, 23, '2021-12-22 02:40:05.000000');
INSERT INTO `common_event` VALUES (52, 32, '2021-12-22 02:40:05.000000');

-- ----------------------------
-- Table structure for common_patient
-- ----------------------------
DROP TABLE IF EXISTS `common_patient`;
CREATE TABLE `common_patient`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `address` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `height` decimal(4, 3) NULL DEFAULT NULL,
  `weight` decimal(4, 1) NULL DEFAULT NULL,
  `birthdate` date NULL DEFAULT NULL,
  `phoneNumber` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `officeNumber` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 37 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of common_patient
-- ----------------------------
INSERT INTO `common_patient` VALUES (2, 'Wen', 'Shanghai', 1.050, 29.0, '2017-04-12', '19907114677', 'S001');
INSERT INTO `common_patient` VALUES (3, 'SG', 'DongChuan', 1.050, 70.0, '2001-01-01', '17777777777', 'S001');
INSERT INTO `common_patient` VALUES (4, '大龙', '东川路', 1.030, 80.0, '2002-01-02', '19999999999', 'S002');
INSERT INTO `common_patient` VALUES (5, '小龙', '剑川路', 1.050, 65.0, '2019-02-01', '10909090909', 'S003');
INSERT INTO `common_patient` VALUES (7, '小王', '浦东新区', 1.080, 40.0, '2011-02-03', '19099099091', 'S001');
INSERT INTO `common_patient` VALUES (8, '小米', '东川路', 1.890, 80.0, '1999-01-01', '19907114677', 'S002');
INSERT INTO `common_patient` VALUES (9, 'Zitong Yu', 'Baoshan', 1.800, 85.0, '2003-09-19', '13576827764', 'NF0212478');
INSERT INTO `common_patient` VALUES (10, 'Zhihao Xiong', 'Jingan', 1.760, 76.0, '2012-09-19', '13576823325', 'NF0232479');
INSERT INTO `common_patient` VALUES (11, 'Heng Yu', 'Minghang', 1.690, 66.0, '2004-00-20', '15976827764', 'NF0122480');
INSERT INTO `common_patient` VALUES (12, 'Peiyao Qin', 'Qinghai', 1.630, 52.0, '2011-03-20', '13577354709', 'NF1212483');
INSERT INTO `common_patient` VALUES (13, 'Jun Huang', 'Minghang', 1.720, 66.0, '2011-01-20', '18927359067', 'NG2359238');
INSERT INTO `common_patient` VALUES (14, 'Kun Ren', 'Minghang', 1.440, 45.0, '2011-02-20', '13533628735', 'NG8357395');
INSERT INTO `common_patient` VALUES (15, 'Yuan Zhong', 'Minghang', 1.650, 48.0, '2011-04-20', '15754354709', 'NC36559YY');
INSERT INTO `common_patient` VALUES (16, '周童', '闵行区东川路', 1.580, 47.0, '2011-05-20', '13577354721', 'NC237T398');
INSERT INTO `common_patient` VALUES (17, '赵浩南', '闵行区东川路', 1.520, 42.0, '2011-00-20', '13587632209', 'NF434859Y');
INSERT INTO `common_patient` VALUES (18, '孙文凯', '闵行区东川路', 1.790, 65.0, '2011-03-20', '13577354719', 'NT2385320');
INSERT INTO `common_patient` VALUES (19, '王维逸', '闵行区东川路', 1.760, 59.0, '2011-03-20', '13565234709', 'NT2435935');
INSERT INTO `common_patient` VALUES (20, '陈浩龙', '闵行区东川路', 1.730, 70.0, '2011-01-20', '13577359086', 'NY2395652');
INSERT INTO `common_patient` VALUES (21, '唐浩迪', '闵行区东川路', 1.650, 54.0, '2011-03-20', '15920354709', 'NY2847535');
INSERT INTO `common_patient` VALUES (22, '刘臻桢', '宝山区', 1.670, 51.0, '2012-03-20', '15991354721', 'NG9275385');
INSERT INTO `common_patient` VALUES (23, '嵇广宇', '宝山区', 1.510, 45.0, '2001-03-20', '18777354732', 'NY2353535');
INSERT INTO `common_patient` VALUES (24, '姜宗霖', '宝山区', 1.340, 40.0, '2011-03-20', '18711354743', 'NF0393855');
INSERT INTO `common_patient` VALUES (25, '张云帆', '宝山区', 1.770, 69.0, '2008-01-20', '13873754701', 'NF8427503');
INSERT INTO `common_patient` VALUES (26, '池哲瀛', '宝山区', 1.350, 37.0, '2009-02-20', '18796154709', 'NG2714629');
INSERT INTO `common_patient` VALUES (27, '王冠翔', '宝山区', 1.680, 53.0, '2003-03-20', '13673245470', 'NT2846274');
INSERT INTO `common_patient` VALUES (28, '吴泽昊', '静安区', 1.760, 67.0, '2001-02-20', '13534354741', 'NF1827420');
INSERT INTO `common_patient` VALUES (29, '厉明航', '静安区', 1.820, 78.0, '2011-02-20', '13577355634', 'ND9247242');
INSERT INTO `common_patient` VALUES (30, '石延龙', '静安区', 1.430, 40.0, '2011-01-20', '13577355789', 'NY2814294');
INSERT INTO `common_patient` VALUES (31, '郝江旭', '静安区', 1.580, 58.0, '2002-03-20', '13523357686', 'ND2842940');
INSERT INTO `common_patient` VALUES (32, '马致遥', '静安区', 1.730, 70.0, '2011-03-20', '13332448901', 'NF1242948');
INSERT INTO `common_patient` VALUES (33, '陈晓宇', '浦东新区', 1.540, 43.0, '2010-03-20', '13512837302', 'NG2184224');
INSERT INTO `common_patient` VALUES (34, '林翀', '浦东新区', 1.630, 45.0, '2010-03-20', '15927284619', 'NT7239364');
INSERT INTO `common_patient` VALUES (35, '修炜杰', '浦东新区', 1.580, 46.0, '2010-02-20', '18539234830', 'NC5623789');
INSERT INTO `common_patient` VALUES (36, 'George', '东川路', 1.800, 75.0, '2000-01-05', '19099099099', 'S005');

-- ----------------------------
-- Table structure for common_record
-- ----------------------------
DROP TABLE IF EXISTS `common_record`;
CREATE TABLE `common_record`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` date NOT NULL,
  `start` datetime(6) NOT NULL,
  `end` datetime(6) NOT NULL,
  `patient_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `common_record_patient_id_85d4f8bb_fk_common_patient_id`(`patient_id`) USING BTREE,
  CONSTRAINT `common_record_patient_id_85d4f8bb_fk_common_patient_id` FOREIGN KEY (`patient_id`) REFERENCES `common_patient` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 34 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of common_record
-- ----------------------------
INSERT INTO `common_record` VALUES (3, 'tr03-0005', '2021-09-11', '2021-09-11 09:00:00.000000', '2021-09-11 19:00:00.000000', 2);
INSERT INTO `common_record` VALUES (7, 'tr03-0007', '2022-01-04', '2022-01-04 09:00:00.000000', '2022-01-04 19:00:00.000000', 4);
INSERT INTO `common_record` VALUES (8, 'tr03-0012', '2021-12-03', '2021-12-03 21:00:00.000000', '2021-12-04 08:00:00.000000', 8);
INSERT INTO `common_record` VALUES (9, 'tr03-0013', '2021-12-04', '2021-12-04 22:00:00.000000', '2021-12-05 06:00:00.000000', 9);
INSERT INTO `common_record` VALUES (10, 'tr03-0014', '2021-12-04', '2021-12-04 23:00:00.000000', '2021-12-05 08:00:00.000000', 10);
INSERT INTO `common_record` VALUES (11, 'tr03-0015', '2021-12-04', '2021-12-04 09:00:00.000000', '2021-12-04 21:00:00.000000', 11);
INSERT INTO `common_record` VALUES (12, 'tr03-0016', '2021-12-07', '2021-12-07 22:00:00.000000', '2021-12-08 06:00:00.000000', 12);
INSERT INTO `common_record` VALUES (13, 'tr03-0017', '2021-12-07', '2021-12-07 21:30:00.000000', '2021-12-08 07:30:00.000000', 13);
INSERT INTO `common_record` VALUES (14, 'tr03-0018', '2021-12-09', '2021-12-09 20:00:00.000000', '2021-12-10 08:00:00.000000', 14);
INSERT INTO `common_record` VALUES (15, 'tr03-0019', '2021-12-10', '2021-12-10 15:00:00.000000', '2021-12-10 23:00:00.000000', 15);
INSERT INTO `common_record` VALUES (16, 'tr03-0020', '2021-12-11', '2021-12-11 23:00:00.000000', '2021-12-12 09:00:00.000000', 16);
INSERT INTO `common_record` VALUES (17, 'tr03-0021', '2021-12-12', '2021-12-12 22:30:00.000000', '2021-12-13 08:00:00.000000', 17);
INSERT INTO `common_record` VALUES (18, 'tr03-0022', '2021-12-13', '2021-12-13 16:00:00.000000', '2021-12-13 23:00:00.000000', 18);
INSERT INTO `common_record` VALUES (19, 'tr03-0023', '2021-12-13', '2021-12-13 20:00:00.000000', '2021-12-14 08:00:00.000000', 19);
INSERT INTO `common_record` VALUES (20, 'tr03-0024', '2021-12-14', '2021-12-14 21:00:00.000000', '2021-12-15 06:00:00.000000', 20);
INSERT INTO `common_record` VALUES (21, 'tr03-0025', '2021-12-15', '2021-12-15 22:00:00.000000', '2021-12-16 07:00:00.000000', 21);
INSERT INTO `common_record` VALUES (22, 'tr03-0026', '2021-12-17', '2021-12-17 14:00:00.000000', '2021-12-17 22:00:00.000000', 22);
INSERT INTO `common_record` VALUES (23, 'tr03-0027', '2021-12-18', '2021-12-18 22:00:00.000000', '2021-12-19 06:00:00.000000', 23);
INSERT INTO `common_record` VALUES (24, 'tr03-0028', '2021-12-19', '2021-12-19 21:00:00.000000', '2021-12-20 07:30:00.000000', 24);
INSERT INTO `common_record` VALUES (25, 'tr03-0029', '2021-12-20', '2021-12-20 21:00:00.000000', '2021-12-21 07:20:00.000000', 25);
INSERT INTO `common_record` VALUES (26, 'tr03-0030', '2021-12-21', '2021-12-21 23:00:00.000000', '2021-12-22 07:40:00.000000', 26);
INSERT INTO `common_record` VALUES (27, 'tr03-0031', '2021-12-22', '2021-12-22 21:00:00.000000', '2021-12-23 07:00:00.000000', 27);
INSERT INTO `common_record` VALUES (28, 'tr03-0032', '2021-12-22', '2021-12-22 22:00:00.000000', '2021-12-23 08:20:00.000000', 28);
INSERT INTO `common_record` VALUES (29, 'tr03-0033', '2021-12-22', '2021-12-22 21:00:00.000000', '2021-12-23 05:00:00.000000', 29);
INSERT INTO `common_record` VALUES (30, 'tr03-0034', '2021-12-22', '2021-12-22 23:00:00.000000', '2021-12-23 06:00:00.000000', 30);
INSERT INTO `common_record` VALUES (31, 'tr03-0035', '2022-01-03', '2022-01-03 23:00:00.000000', '2022-01-04 07:00:00.000000', 31);
INSERT INTO `common_record` VALUES (32, 'tr03-0036', '2022-01-03', '2022-01-03 20:00:00.000000', '2022-01-04 05:00:00.000000', 32);
INSERT INTO `common_record` VALUES (33, 'tr03-0037', '2022-01-04', '2022-01-04 21:00:00.000000', '2022-01-05 06:00:00.000000', 33);
INSERT INTO `common_record` VALUES (34, 'tr05-0005', '2021-05-06', '2021-05-06 09:00:00.000000', '2021-05-06 19:00:00.000000', 10);
INSERT INTO `common_record` VALUES (35, 'tr05-0007', '2021-05-07', '2021-05-07 09:00:00.000000', '2021-05-07 09:00:00.000000', 10);

-- ----------------------------
-- Table structure for common_sleepevent
-- ----------------------------
DROP TABLE IF EXISTS `common_sleepevent`;
CREATE TABLE `common_sleepevent`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `stage` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `start` datetime(6) NOT NULL,
  `record_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `common_sleepevent_record_id_f17da9a2_fk_common_record_id`(`record_id`) USING BTREE,
  CONSTRAINT `common_sleepevent_record_id_f17da9a2_fk_common_record_id` FOREIGN KEY (`record_id`) REFERENCES `common_record` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 53 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of common_sleepevent
-- ----------------------------
INSERT INTO `common_sleepevent` VALUES (5, 'N1', '2022-01-04 09:00:05.000000', 3);
INSERT INTO `common_sleepevent` VALUES (29, 'N2', '2021-12-03 23:00:00.000000', 8);
INSERT INTO `common_sleepevent` VALUES (30, 'N3', '2021-12-04 00:00:00.000000', 8);
INSERT INTO `common_sleepevent` VALUES (31, 'R', '2021-12-04 00:40:00.000000', 8);
INSERT INTO `common_sleepevent` VALUES (32, 'N1', '2021-12-04 23:54:00.000000', 10);
INSERT INTO `common_sleepevent` VALUES (33, 'W', '2021-12-04 23:22:00.000000', 10);
INSERT INTO `common_sleepevent` VALUES (34, 'W', '2021-12-04 09:00:00.000000', 11);
INSERT INTO `common_sleepevent` VALUES (35, 'N1', '2021-12-04 09:38:00.000000', 11);
INSERT INTO `common_sleepevent` VALUES (36, 'N2', '2021-12-04 10:22:00.000000', 11);
INSERT INTO `common_sleepevent` VALUES (37, 'R', '2021-12-10 00:00:00.000000', 14);
INSERT INTO `common_sleepevent` VALUES (38, 'N2', '2021-12-10 16:54:00.000000', 15);
INSERT INTO `common_sleepevent` VALUES (39, 'N3', '2021-12-12 01:00:00.000000', 16);
INSERT INTO `common_sleepevent` VALUES (40, 'R', '2021-12-12 02:00:00.000000', 16);
INSERT INTO `common_sleepevent` VALUES (41, 'N1', '2021-12-12 23:30:00.000000', 17);
INSERT INTO `common_sleepevent` VALUES (42, 'N1', '2021-12-13 17:00:00.000000', 18);
INSERT INTO `common_sleepevent` VALUES (43, 'N1', '2021-12-13 21:00:00.000000', 19);
INSERT INTO `common_sleepevent` VALUES (44, 'N2', '2021-12-14 22:48:00.000000', 20);
INSERT INTO `common_sleepevent` VALUES (45, 'N2', '2021-12-15 23:50:00.000000', 21);
INSERT INTO `common_sleepevent` VALUES (46, 'R', '2021-12-17 16:30:00.000000', 22);
INSERT INTO `common_sleepevent` VALUES (47, 'N3', '2021-12-17 17:30:00.000000', 22);
INSERT INTO `common_sleepevent` VALUES (48, 'R', '2021-12-21 01:20:00.000000', 25);
INSERT INTO `common_sleepevent` VALUES (49, 'R', '2021-12-22 00:40:00.000000', 26);
INSERT INTO `common_sleepevent` VALUES (52, 'W', '2021-12-22 02:40:05.000000', 32);

-- ----------------------------
-- Table structure for django_admin_log
-- ----------------------------
DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `object_repr` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `content_type_id` int NULL DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `django_admin_log_content_type_id_c4bce8eb_fk_django_co`(`content_type_id`) USING BTREE,
  INDEX `django_admin_log_user_id_c564eba6_fk_auth_user_id`(`user_id`) USING BTREE,
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_admin_log
-- ----------------------------

-- ----------------------------
-- Table structure for django_content_type
-- ----------------------------
DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `model` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `django_content_type_app_label_model_76bd3d3b_uniq`(`app_label`, `model`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_content_type
-- ----------------------------
INSERT INTO `django_content_type` VALUES (1, 'admin', 'logentry');
INSERT INTO `django_content_type` VALUES (3, 'auth', 'group');
INSERT INTO `django_content_type` VALUES (2, 'auth', 'permission');
INSERT INTO `django_content_type` VALUES (4, 'auth', 'user');
INSERT INTO `django_content_type` VALUES (8, 'common', 'breathevent');
INSERT INTO `django_content_type` VALUES (9, 'common', 'diagnosis');
INSERT INTO `django_content_type` VALUES (7, 'common', 'event');
INSERT INTO `django_content_type` VALUES (10, 'common', 'patient');
INSERT INTO `django_content_type` VALUES (11, 'common', 'record');
INSERT INTO `django_content_type` VALUES (12, 'common', 'sleepevent');
INSERT INTO `django_content_type` VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO `django_content_type` VALUES (6, 'sessions', 'session');

-- ----------------------------
-- Table structure for django_migrations
-- ----------------------------
DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 36 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_migrations
-- ----------------------------
INSERT INTO `django_migrations` VALUES (1, 'contenttypes', '0001_initial', '2022-01-13 01:16:52.097966');
INSERT INTO `django_migrations` VALUES (2, 'auth', '0001_initial', '2022-01-13 01:16:52.896944');
INSERT INTO `django_migrations` VALUES (3, 'admin', '0001_initial', '2022-01-13 01:16:53.120343');
INSERT INTO `django_migrations` VALUES (4, 'admin', '0002_logentry_remove_auto_add', '2022-01-13 01:16:53.133308');
INSERT INTO `django_migrations` VALUES (5, 'admin', '0003_logentry_add_action_flag_choices', '2022-01-13 01:16:53.143281');
INSERT INTO `django_migrations` VALUES (6, 'contenttypes', '0002_remove_content_type_name', '2022-01-13 01:16:53.263769');
INSERT INTO `django_migrations` VALUES (7, 'auth', '0002_alter_permission_name_max_length', '2022-01-13 01:16:53.518831');
INSERT INTO `django_migrations` VALUES (8, 'auth', '0003_alter_user_email_max_length', '2022-01-13 01:16:53.611428');
INSERT INTO `django_migrations` VALUES (9, 'auth', '0004_alter_user_username_opts', '2022-01-13 01:16:53.624394');
INSERT INTO `django_migrations` VALUES (10, 'auth', '0005_alter_user_last_login_null', '2022-01-13 01:16:53.688223');
INSERT INTO `django_migrations` VALUES (11, 'auth', '0006_require_contenttypes_0002', '2022-01-13 01:16:53.693252');
INSERT INTO `django_migrations` VALUES (12, 'auth', '0007_alter_validators_add_error_messages', '2022-01-13 01:16:53.704180');
INSERT INTO `django_migrations` VALUES (13, 'auth', '0008_alter_user_username_max_length', '2022-01-13 01:16:53.807903');
INSERT INTO `django_migrations` VALUES (14, 'auth', '0009_alter_user_last_name_max_length', '2022-01-13 01:16:53.931572');
INSERT INTO `django_migrations` VALUES (15, 'auth', '0010_alter_group_name_max_length', '2022-01-13 01:16:53.955508');
INSERT INTO `django_migrations` VALUES (16, 'auth', '0011_update_proxy_permissions', '2022-01-13 01:16:53.967476');
INSERT INTO `django_migrations` VALUES (17, 'auth', '0012_alter_user_first_name_max_length', '2022-01-13 01:16:54.050255');
INSERT INTO `django_migrations` VALUES (18, 'common', '0001_initial', '2022-01-13 01:16:54.082169');
INSERT INTO `django_migrations` VALUES (19, 'common', '0002_customer_qq', '2022-01-13 01:16:54.106105');
INSERT INTO `django_migrations` VALUES (20, 'common', '0003_remove_customer_qq', '2022-01-13 01:16:54.155972');
INSERT INTO `django_migrations` VALUES (21, 'common', '0004_medicine_order', '2022-01-13 01:16:54.277647');
INSERT INTO `django_migrations` VALUES (22, 'common', '0005_auto_20181224_2116', '2022-01-13 01:16:54.453563');
INSERT INTO `django_migrations` VALUES (23, 'common', '0006_order_medicinelist', '2022-01-13 01:16:54.482479');
INSERT INTO `django_migrations` VALUES (24, 'common', '0007_auto_20211225_1639', '2022-01-13 01:16:55.309630');
INSERT INTO `django_migrations` VALUES (25, 'common', '0008_auto_20211225_1939', '2022-01-13 01:16:56.203892');
INSERT INTO `django_migrations` VALUES (26, 'common', '0009_auto_20211225_1944', '2022-01-13 01:16:56.220856');
INSERT INTO `django_migrations` VALUES (27, 'common', '0010_auto_20211225_2101', '2022-01-13 01:16:56.311571');
INSERT INTO `django_migrations` VALUES (28, 'common', '0011_event', '2022-01-13 01:16:56.342525');
INSERT INTO `django_migrations` VALUES (29, 'common', '0012_auto_20211226_2307', '2022-01-13 01:16:56.384375');
INSERT INTO `django_migrations` VALUES (30, 'common', '0013_auto_20211227_0011', '2022-01-13 01:16:56.586839');
INSERT INTO `django_migrations` VALUES (31, 'common', '0014_auto_20220113_0916', '2022-01-13 01:16:58.199934');
INSERT INTO `django_migrations` VALUES (32, 'sessions', '0001_initial', '2022-01-13 01:16:58.254787');
INSERT INTO `django_migrations` VALUES (33, 'common', '0015_auto_20220113_0919', '2022-01-13 01:19:12.341527');
INSERT INTO `django_migrations` VALUES (34, 'common', '0016_auto_20220113_2107', '2022-01-13 13:08:01.149186');
INSERT INTO `django_migrations` VALUES (35, 'common', '0017_auto_20220113_2114', '2022-01-13 13:14:18.141668');

-- ----------------------------
-- Table structure for django_session
-- ----------------------------
DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session`  (
  `session_key` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `session_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`) USING BTREE,
  INDEX `django_session_expire_date_a5c62663`(`expire_date`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of django_session
-- ----------------------------
INSERT INTO `django_session` VALUES ('0bwr6h8qhuybp4nt0hsgmp9e4g8p3fvf', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7t8a:HTMLt7EBhfKyKbe8YjSD9qy4Z1aj1X5sXuywFB3KQd8', '2022-01-27 05:59:04.574333');
INSERT INTO `django_session` VALUES ('2fkqn1j6paa06uz4wka281ujyn2rdgij', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8JJZ:kFPw1z5GLfv0Tf8RRvj86AdNDTo6UqMITlqo5nYfPfk', '2022-01-28 09:56:09.206450');
INSERT INTO `django_session` VALUES ('5zy0gjnva0wzt0kpr7nsd4eiysiv2icb', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8IvF:5Bq6bAmLh1u9940DuZXkI7TP6kzucUg6FKf1rDZ1wyc', '2022-01-28 09:31:01.813717');
INSERT INTO `django_session` VALUES ('779m2qjt5t2jgpuwkgcnwmuyjorjc7q1', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7tFe:5GuUHNJSUC6B6TsZTcMjXjBLTfSr_SytvE8bMKMsR9A', '2022-01-27 06:06:22.760595');
INSERT INTO `django_session` VALUES ('8jv6hcqh3wy1xous1ipkc72m9e8laavh', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7qSm:k1HZFwgcjEDrKi8nJPD1wQtDsHNNESws4L5_hnwCDDE', '2022-01-27 03:07:44.809029');
INSERT INTO `django_session` VALUES ('931jslfomnfp9lai5yg0u6pql47zn3te', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8OA6:eJbtEoBzcGxCw6ke4qeRi8rwARhMzN9xpa4vb-SLYK8', '2022-01-28 15:06:42.107820');
INSERT INTO `django_session` VALUES ('9ay9564kg9m60xkn5yl9kpy2agbgr9dc', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7vR4:ePtLABWMIdkCYE3JfN_e8YmldPy_uqNNhQvZ4rys2ZU', '2022-01-27 08:26:18.746999');
INSERT INTO `django_session` VALUES ('ak2m01s0wl4d9gbndn8todjy27zfnh0d', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n820u:3lq1Lrooctb4EN-7_WNXenJyNG4H4Wyfkj5Txe8--zc', '2022-01-27 15:27:44.123009');
INSERT INTO `django_session` VALUES ('ayjar1w1627p9jj3dazyggdlox0214ot', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7qU4:NegSmqBlAR-YviCQfU4J_vmHjmC-RZ-TakfIGkL8iuE', '2022-01-27 03:09:04.047437');
INSERT INTO `django_session` VALUES ('ck3ig3o38bk470otly9wr1f2gr5qobd5', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8LIy:o8s1YhXc4gOoX1I6baUkeydfBHYS3Rvyq5VZBLUc72w', '2022-01-28 12:03:40.075710');
INSERT INTO `django_session` VALUES ('g5rv11gpb2r6tjkmwgxdoroevh1kqdaa', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7sno:clCi_CRzzqDFB63_gISOJ1eAZ20KBKIWmwfBS_Xu-cw', '2022-01-27 05:37:36.696373');
INSERT INTO `django_session` VALUES ('lajzg561htgfahnbu2j4uszg42uiifog', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8Npa:qripmrK_XtUgglRbEcRNuugJQknj4S8eQfhIbt-8wFk', '2022-01-28 14:45:30.362983');
INSERT INTO `django_session` VALUES ('mdgco1dcpwxqgebp4dzq6q9tdb9hv1m2', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8fG0:MwTNGiP3niAkvjd5V6PHTVGaxv4Nkt5FG5iG6nqP8PA', '2022-01-29 09:21:56.654477');
INSERT INTO `django_session` VALUES ('n0vihky3oel61k6hvs301ydh3btgszm3', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7xCd:4VtMXre1vet7RQ4ADW7ZCNb7hsBri1Uu9kmP9y7v9DQ', '2022-01-27 10:19:31.777674');
INSERT INTO `django_session` VALUES ('nxzb3khxzig4wej4toukmjt5y9pcaki3', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7wXa:x3OVNoz0n9eSaSu_4okWWYMZ8gRqlXV7blWWH5NnZxs', '2022-01-27 09:37:06.985059');
INSERT INTO `django_session` VALUES ('oqfsjg9kel5nxsxfuejpylexwdr1950d', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7wX4:--QEo8bKiz3DynablUdXJVxWvt5wqvlxexcyhUZARLk', '2022-01-27 09:36:34.720864');
INSERT INTO `django_session` VALUES ('qrhf30524o3rjihzk0p023qq5jvyudqp', '.eJxVjDsOwyAQBe9CHSE-C15SpvcZELA4OIlAMnYV5e6xJRdJ-2bmvZkP21r81vPiZ2JXJtnld4shPXM9AD1CvTeeWl2XOfJD4SftfGyUX7fT_TsooZe9dsokaUWcoiDMCkirQQ4JjNEE0gl0IJSNKC2iMBMkqw05F_YMBFpgny-yBTYr:1n7ott:mAy0jo6eOYh0BNxGAFpf3DIAhQKkP0YPVlmpCaPrwDs', '2022-01-27 01:27:37.519445');
INSERT INTO `django_session` VALUES ('rhd5mxj4iiy4jx5lr4pmeyxr2eb1s5go', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8OIM:md2MJ29EP5V5CpEsPLPK-ZCkKEzUWCifrwdue_jWo1I', '2022-01-28 15:15:14.086372');
INSERT INTO `django_session` VALUES ('uwrfzvonhdx3og21wcjwpgua527c1cl3', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8iRx:vAOkmk3ezseIFPKOh86sa8oDtXCTlPucRGkGCcifEYM', '2022-01-29 12:46:29.184926');
INSERT INTO `django_session` VALUES ('vbvvfdqwlcsebt2k2bnvml3klkkvoeqz', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n8OFf:G9FiA2raM-sNqqC-zjnvj7_lFz_ZYmfND4NWFZjjyUY', '2022-01-28 15:12:27.261526');
INSERT INTO `django_session` VALUES ('w4p1a1a222bfrml38ujjizkbf4nlbk8u', '.eJxVjDsOwyAQBe9CHSHAC4aU6XMGC1hsnI-xDC6iKHcPSC6S9s2beZPB7iUOew7bMCM5E05Ov5uz_h6WBvBmlylRn5ayzY62Cz1opteE4XE5vn-BaHOsthHSc8Xc6BjqIAA70fPeg5QdAjdMG2BCOc2V1kyO4FUn0RhbNWBaQY22XHmtodae00Y-X3zfO-A:1n7xvC:p5zb-jEp4UeszDmFkMg5h73GoG6e7IdMan_eW62mmSI', '2022-01-27 11:05:34.638989');

-- ----------------------------
-- View structure for doctor_view_patient
-- ----------------------------
DROP VIEW IF EXISTS `doctor_view_patient`;
CREATE ALGORITHM = UNDEFINED SQL SECURITY DEFINER VIEW `doctor_view_patient` AS select `common_diagnosis`.`id` AS `id`,`common_diagnosis`.`pid_id` AS `pid_id`,`common_diagnosis`.`user_id` AS `user_id`,`common_patient`.`name` AS `name`,`common_patient`.`address` AS `address`,`common_patient`.`height` AS `height`,`common_patient`.`weight` AS `weight`,`common_patient`.`birthdate` AS `birthdate`,`common_patient`.`phoneNumber` AS `phoneNumber`,`common_patient`.`officeNumber` AS `officeNumber` from ((`auth_user` join `common_diagnosis` on((`auth_user`.`id` = `common_diagnosis`.`user_id`))) join `common_patient` on((`common_diagnosis`.`pid_id` = `common_patient`.`id`)));

SET FOREIGN_KEY_CHECKS = 1;
