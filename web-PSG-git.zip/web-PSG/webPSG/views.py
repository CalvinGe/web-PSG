from django.http import HttpResponse
from django.shortcuts import render

from tkinter import messagebox, mainloop


def code(request):
    if request.method == "POST":
        filename = request.FILES['file'].name
        with open('edf_data/'+filename, 'wb') as f:
            for chunk in request.FILES['file'].chunks():
                f.write(chunk)
        return HttpResponse('上传成功')
    return render(request, 'upload.html')