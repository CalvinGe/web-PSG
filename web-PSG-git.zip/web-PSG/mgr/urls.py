from django.urls import path

from mgr import sign_in_out, patient, record, sleepEvent, event, breathEvent, views

urlpatterns = [

    path('patients', patient.dispatcher),
    path('records', record.dispatcher),
    path('sleepevents', sleepEvent.dispatcher),
    path('breathevents', breathEvent.dispatcher),
    path('events', event.dispatcher),
    path('signin', sign_in_out.signin),
    path('signout', sign_in_out.signout),
    path('register', views.register)
]
