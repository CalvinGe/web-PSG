from django.http import JsonResponse

import traceback

# 导入 Patient 对象定义
from common.models import Patient, Diagnosis
from common.doctor_view_patient import PatientinfoOrm

from django.core.paginator import Paginator, EmptyPage
from django.db.models import Q

from django_redis import get_redis_connection
from webPSG import settings
import json

# 获取一个和Redis服务的连接
rconn = get_redis_connection("default")


def listpatient(request):

    try:
        diag_qs = PatientinfoOrm.objects.values().order_by('-id')
        current_user = request.user
        # 当前医生用户的ID
        ID = current_user.id
        diag_qs = diag_qs.filter(user_id=ID)
        # condtions: {'user_id': ID}
        # diag_qs = diag_qs.filter(**condtions)
        # print(diag_qs)
        # 返回一个 QuerySet 对象 ，包含所有的表记录
        qs = Patient.objects.values().order_by('-id')

        # 查看是否有 关键字 搜索 参数
        keywords = request.params.get('keywords',None)
        if keywords:
            conditions = [Q(name__contains=one) for one in keywords.split(' ') if one]
            query = Q()
            for condition in conditions:
                query &= condition
            qs = qs.filter(query)

        print(diag_qs.values)
        # 要获取的第几页
        pagenum = request.params['pagenum']

        # 每页要显示多少条记录
        pagesize = request.params['pagesize']

        # 使用分页对象，设定每页多少条记录
        pgnt = Paginator(diag_qs, pagesize)

        # 从数据库中读取数据，指定读取其中第几页
        page = pgnt.page(pagenum)

        # 将 QuerySet 对象 转化为 list 类型
        retlist = list(page)

        # total指定了 一共有多少数据
        return JsonResponse({'ret': 0, 'retlist': retlist,'total': pgnt.count})

    except EmptyPage:
        return JsonResponse({'ret': 0, 'retlist': [], 'total': 0})

    except:
        return JsonResponse({'ret': 2,  'msg': f'未知错误\n{traceback.format_exc()}'})



def addpatient(request):
    info = request.params['data']

    # 从请求消息中 获取要添加客户的信息
    # 并且插入到数据库中
    patient = Patient.objects.create(name=info['name'],
                                     address=info['address'],
                                     height=info['height'],
                                     weight=info['weight'],
                                     birthdate=info['birthdate'],
                                     phoneNumber=info['phoneNumber'],
                                     officeNumber=info['officeNumber'])
    current_user = request.user
    ID = current_user.id
    diagnosis = Diagnosis.objects.create(pid_id=patient.id,
                                         user_id=ID)

    # 同时删除整个 patient 缓存数据
    # 因为不知道这个添加的病人会影响到哪些列出的结果
    # 只能全部删除
    rconn.delete(settings.CK.MedineList)

    return JsonResponse({'ret': 0, 'id': patient.id})


def modifypatient(request):
    # 从请求消息中 获取修改病人的信息
    # 找到该病人，并且进行修改操作

    patientid = request.params['id']
    newdata = request.params['newdata']

    try:
        # 根据 id 从数据库中找到相应的客户记录
        patient = Patient.objects.get(id=patientid)
    except patient.DoesNotExist:
        return {
            'ret': 1,
            'msg': f'id 为`{patientid}`的病人不存在'
        }

    if 'name' in newdata:
        patient.name = newdata['name']
    if 'address' in newdata:
        patient.address = newdata['address']
    if 'height' in newdata:
        patient.height = newdata['height']
    if 'weight' in newdata:
        patient.height = newdata['weight']
    if 'birthdate' in newdata:
        patient.height = newdata['birthdate']
    if 'phoneNumber' in newdata:
        patient.height = newdata['phoneNumber']
    if 'officeNumber' in newdata:
        patient.height = newdata['officeNumber']

    # 注意，一定要执行save才能将修改信息保存到数据库
    patient.save()

    # 同时删除整个 patient 缓存
    # 因为不知道这个修改的病人会影响到哪些列出的结果
    # 只能全部删除
    rconn.delete(settings.CK.MedineList)

    return JsonResponse({'ret': 0})


def deletepatient(request):
    patientid = request.params['id']

    try:
        # 根据 id 从数据库中找到相应的药品记录
        patient = Patient.objects.get(id=patientid)
    except Patient.DoesNotExist:
        return {
            'ret': 1,
            'msg': f'id 为`{patientid}`的客户不存在'
        }

    # delete 方法就将该记录从数据库中删除了
    patient.delete()

    # 同时删除整个 patient 缓存数据
    # 因为不知道这个删除的病人会影响到哪些列出的结果
    # 只能全部删除
    rconn.delete(settings.CK.MedineList)

    return JsonResponse({'ret': 0})


from lib.handler import dispatcherBase

Action2Handler = {
    'list_patient': listpatient,
    'add_patient': addpatient,
    'modify_patient': modifypatient,
    'del_patient': deletepatient,
}


def dispatcher(request):
    return dispatcherBase(request, Action2Handler)
