from django.db import models
from django.contrib.auth.models import User
import datetime


# 病人（patient）
class Patient(models.Model):
    id = models.AutoField(primary_key=True)
    # 病人名
    name = models.CharField(max_length=200)
    # 地址
    address = models.CharField(max_length=200)
    # 身高/m
    height = models.DecimalField(decimal_places=3, max_digits=4, null=True)
    # 体重/kg
    weight = models.DecimalField(decimal_places=1, max_digits=4, null=True)
    # 出生年月日
    birthdate = models.DateField(null=True)
    # 联系人电话
    phoneNumber = models.CharField(max_length=200, null=True)
    # 住院门诊号
    officeNumber = models.CharField(max_length=200, null=True)


# 记录
class Record(models.Model):
    id = models.AutoField(primary_key=True)
    # 对应的病人
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    # 记录名，与文件名(如tr03-0005)保持一致
    name = models.CharField(max_length=50)
    # 记录日期
    date = models.DateField()
    # 开始时间
    start = models.DateTimeField()
    # 结束时间
    end = models.DateTimeField()


# 事件
class Event(models.Model):
    id = models.AutoField(primary_key=True)
    # 开始时间
    start = models.DateTimeField()
    # 对应的记录
    record = models.ForeignKey(Record, on_delete=models.CASCADE)


# 睡眠事件
class sleepEvent(models.Model):
    id = models.AutoField(primary_key=True)
    # 分期
    stage = models.CharField(max_length=4)
    # 开始时间
    start = models.DateTimeField()
    # 对应的记录
    record = models.ForeignKey(Record, on_delete=models.CASCADE)


# 呼吸事件
class breathEvent(models.Model):
    id = models.AutoField(primary_key=True)
    # 类型
    type = models.CharField(max_length=10)
    # 结束时间
    end = models.DateTimeField()
    # 开始时间
    start = models.DateTimeField()
    # 对应的记录
    record = models.ForeignKey(Record, on_delete=models.CASCADE)


# 医生诊断病人
class Diagnosis(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    pid = models.ForeignKey(Patient, on_delete=models.CASCADE)


from django.contrib import admin

admin.site.register(Patient)
admin.site.register(Record)
admin.site.register(sleepEvent)
admin.site.register(breathEvent)
admin.site.register(Event)
