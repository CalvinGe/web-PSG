from .models import *


class PatientinfoOrm(models.Model):
    pid_id = models.CharField(max_length=50)
    user_id = models.CharField(max_length=50)
    # 病人名
    name = models.CharField(max_length=200)
    # 地址
    address = models.CharField(max_length=200)
    # 身高/m
    height = models.DecimalField(decimal_places=3, max_digits=4, null=True)
    # 体重/kg
    weight = models.DecimalField(decimal_places=1, max_digits=4, null=True)
    # 出生年月日
    birthdate = models.DateField(null=True)
    # 联系人电话
    phoneNumber = models.CharField(max_length=200, null=True)
    # 住院门诊号
    officeNumber = models.CharField(max_length=200, null=True)

    class Meta:
        db_table = 'doctor_view_patient'
