from django.test import TestCase

import json
from common.models import Patient
from django.db import IntegrityError, transaction
from django.http import JsonResponse

