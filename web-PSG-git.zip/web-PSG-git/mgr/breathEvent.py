from django.http import JsonResponse

import traceback

# 导入 event 对象定义
from common.models import Event, breathEvent

from django.core.paginator import Paginator, EmptyPage
from django.db.models import Q

from django_redis import get_redis_connection
from webPSG import settings
import json

# 获取一个和Redis服务的连接
rconn = get_redis_connection("default")


def listBreathEvent(request):
    try:
        # 返回一个 QuerySet 对象 ，包含所有的表记录
        qs = breathEvent.objects.values().order_by('-id')

        # 查看是否有 关键字 搜索 参数
        keywords = request.params.get('keywords', None)
        if keywords:
            conditions = [Q(name__contains=one) for one in keywords.split(' ') if one]
            query = Q()
            for condition in conditions:
                query &= condition
            qs = qs.filter(query)

        # 要获取的第几页
        pagenum = request.params['pagenum']

        # 每页要显示多少条记录
        pagesize = request.params['pagesize']

        # 使用分页对象，设定每页多少条记录
        pgnt = Paginator(qs, pagesize)

        # 从数据库中读取数据，指定读取其中第几页
        page = pgnt.page(pagenum)

        # 将 QuerySet 对象 转化为 list 类型
        retlist = list(page)
        print("hi")

        # total指定了 一共有多少数据
        return JsonResponse({'ret': 0, 'retlist': retlist, 'total': pgnt.count})

    except EmptyPage:
        return JsonResponse({'ret': 0, 'retlist': [], 'total': 0})

    except:
        return JsonResponse({'ret': 2, 'msg': f'未知错误\n{traceback.format_exc()}'})


def addBreathEvent(request):
    info = request.params['data']

    # 从请求消息中 获取要添加事件的信息
    # 并且插入到数据库中
    # 先插入一个父类Event
    event = Event.objects.create(record_id=info['record_id'],
                                 start=info['start'])
    # 再插入一个BreathEvent
    breath_event = breathEvent.objects.create(id=event.id,
                                              type=info['type'],
                                              start=info['start'],
                                              end=info['end'],
                                              record_id=info['record_id'])

    # 同时删除整个 breathEvent 缓存数据
    # 因为不知道这个添加的药品会影响到哪些列出的结果
    # 只能全部删除
    rconn.delete(settings.CK.MedineList)

    return JsonResponse({'ret': 0, 'id': breath_event.id})


def modifyBreathEvent(request):
    # 从请求消息中 获取修改客户的信息
    # 找到该客户，并且进行修改操作

    eventid = request.params['id']
    newdata = request.params['newdata']

    try:
        # 根据 id 从数据库中找到相应的客户记录
        breath_event = breathEvent.objects.get(id=eventid)
    except breath_event.DoesNotExist:
        return {
            'ret': 1,
            'msg': f'id 为`{eventid}`的事件不存在'
        }

    if 'start' in newdata:
        breath_event.start = newdata['start']
    if 'type' in newdata:
        breath_event.type = newdata['type']
    if 'end' in newdata:
        breath_event.end = newdata['end']
    if 'record_id' in newdata:
        breath_event.record_id = newdata['record_id']

    # 注意，一定要执行save才能将修改信息保存到数据库
    breath_event.save()

    # 同时删除整个 event 缓存数据
    # 因为不知道这个修改的事件会影响到哪些列出的结果
    # 只能全部删除
    rconn.delete(settings.CK.MedineList)

    return JsonResponse({'ret': 0})


def deleteBreathEvent(request):
    eventid = request.params['id']

    try:
        # 根据 id 从数据库中找到相应的事件记录
        breath_event = breathEvent.objects.get(id=eventid)
        event = Event.objects.get(id=eventid)
    except breath_event.DoesNotExist:
        return {
            'ret': 1,
            'msg': f'id 为`{eventid}`的事件不存在'
        }

    # delete 方法就将该记录从数据库中删除了
    breath_event.delete()
    event.delete()
    # 同时删除整个 event 缓存数据
    # 因为不知道这个删除的事件会影响到哪些列出的结果
    # 只能全部删除
    rconn.delete(settings.CK.MedineList)

    return JsonResponse({'ret': 0})


from lib.handler import dispatcherBase

Action2Handler = {
    'list_breath_event': listBreathEvent,
    'add_breath_event': addBreathEvent,
    'modify_breath_event': modifyBreathEvent,
    'delete_breath_event': deleteBreathEvent,
}


def dispatcher(request):
    return dispatcherBase(request, Action2Handler)
